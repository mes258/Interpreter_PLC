# Interpreter1_PLC
Version 1 of the Interpreter by Vincent Portelli, Michael Smith, and Thomas Lerner.

## How to run the Interpreter
* In `Interpreter1.rkt` add the path any .txt file in place of "code.txt" on line 173 to run the Java/C code in the file. 
* The interpreter will print out the value returned by the given code in the file. 
