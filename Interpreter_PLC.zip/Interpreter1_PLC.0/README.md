# Interpreter1_PLC
Version 1 of the Interpreter by Vincent Portelli, Michael Smith, and Thomas Lerner.

## How to run the Interpreter
* Run `Interpreter1.rkt` and call `(runfile '"<filename>")` such as `(runfile '"code.txt")`. 
* The interpreter will return the value returned by the given code in the file. 
